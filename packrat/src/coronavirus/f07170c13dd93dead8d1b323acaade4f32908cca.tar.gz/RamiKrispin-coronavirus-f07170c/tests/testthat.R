library(testthat)
library(coronavirus)

test_check("coronavirus")
